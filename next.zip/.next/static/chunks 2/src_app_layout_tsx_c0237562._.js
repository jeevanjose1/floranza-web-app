(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__259b11de._.css",
  "static/chunks/_1c476a5d._.js",
  "static/chunks/node_modules_next_4cc4b1cb._.js",
  "static/chunks/node_modules_axios_lib_99999129._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_@tanstack_query-core_build_modern_e1f37cda._.js",
  "static/chunks/node_modules_025a786e._.js"
],
    source: "dynamic"
});
