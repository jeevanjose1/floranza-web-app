(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_eafbd827._.js",
  "static/chunks/src_eedc3f60._.js"
],
    source: "dynamic"
});
