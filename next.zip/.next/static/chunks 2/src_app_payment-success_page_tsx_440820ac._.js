(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@lottiefiles_dotlottie-react_dist_browser_index_7fdfb1aa.js",
  "static/chunks/src_app_payment-success_page_tsx_b465d60f._.js"
],
    source: "dynamic"
});
