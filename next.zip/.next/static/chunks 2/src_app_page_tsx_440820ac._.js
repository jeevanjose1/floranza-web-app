(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_343874f5._.js",
  "static/chunks/node_modules_8c288566._.js"
],
    source: "dynamic"
});
