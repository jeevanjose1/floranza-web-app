(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_d88d7845._.js",
  "static/chunks/node_modules_32d5bed5._.js"
],
    source: "dynamic"
});
